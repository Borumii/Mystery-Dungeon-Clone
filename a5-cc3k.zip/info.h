#ifndef _INFOH_
#define _INFOH_

struct Info
{
	int x,y;
};

#endif

