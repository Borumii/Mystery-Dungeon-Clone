#ifndef __TILE__H
#define __TILE__H

enum Tile {VWall, HWall, Room, Empty, Passage, Stair, Door};

#endif


