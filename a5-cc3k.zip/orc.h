#ifndef ORC_H
#define ORC_H

#include "enemy.h"

// does 50% more damage to goblins (implemented)

class Orc: public Enemy {
	public:
		Orc();
};

#endif


