#include "human.h"

using namespace std;

Human::Human(): Enemy(140, 20, 10, "Human", 'H', 4){
}


