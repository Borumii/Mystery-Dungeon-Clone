#ifndef HUMAN_H
#define HUMAN_H

#include "enemy.h"

// drops 2 normal piles of gold

class Human: public Enemy{	
	public:
		Human();
};

#endif




