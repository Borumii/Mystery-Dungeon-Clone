#ifndef _ITEMH_
#define _ITEMH_

#include "character.h"

class Item: public Character{
	public:
		Item(char new_symbol);
};


#endif


