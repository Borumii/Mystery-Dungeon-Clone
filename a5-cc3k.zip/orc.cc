#include "orc.h"

using namespace std;

Orc::Orc(): Enemy(180, 30, 25, "Orc", 'O'){
}

