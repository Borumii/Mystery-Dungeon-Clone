#ifndef TROLL_H
#define TROLL_H

#include "hero.h"

// regains 5 HP every turn; HP is capped at 120 HP

class Troll: public Hero{
	public:
		Troll();
};

#endif


