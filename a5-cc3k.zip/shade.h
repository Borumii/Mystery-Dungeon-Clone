#ifndef SHADE_H
#define SHADE_H

#include "hero.h"

// no special ability

class Shade: public Hero{
	public:
		Shade();
};

#endif


