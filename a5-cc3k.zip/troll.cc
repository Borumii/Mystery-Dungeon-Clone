#include "troll.h"

Troll::Troll(): Hero(120, 25, 15, "Troll"){
}


