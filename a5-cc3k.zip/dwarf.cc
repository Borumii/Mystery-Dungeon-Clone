#include "dwarf.h"

using namespace std;

Dwarf::Dwarf(): Enemy(100, 20, 30, "Dwarf", 'W'){
}


