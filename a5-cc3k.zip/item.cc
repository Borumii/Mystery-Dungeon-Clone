#include "item.h"

Item::Item(char new_symbol): Character(new_symbol){
}

