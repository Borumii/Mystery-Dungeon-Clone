#include "shade.h"

Shade::Shade(): Hero(125, 25, 25, "Shade"){
}
