#ifndef DWARF_H
#define DWARF_H

#include "enemy.h"

// Vampires are allergic to dwarves and lose 5HP rather than gain (implemented)

class Dwarf: public Enemy{
	public:
		Dwarf();
};

#endif




